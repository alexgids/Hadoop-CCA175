hive -e "DROP TABLE email2dgk_retail_db.departments";
hive -e "DROP TABLE email2dgk_retail_db.departments_external";
