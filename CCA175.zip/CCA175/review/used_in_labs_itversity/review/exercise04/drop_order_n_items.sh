hive << EOF
DROP TABLE IF EXISTS email2dgk_retail_db.order_items_ext;
DROP TABLE IF EXISTS email2dgk_retail_db.order_items;
DROP TABLE IF EXISTS email2dgk_retail_db.orders;
DROP TABLE IF EXISTS email2dgk_retail_db.orders_ext;
EOF
